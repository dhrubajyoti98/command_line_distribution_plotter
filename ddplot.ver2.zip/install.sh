make
sudo apt-get install gnuplot
name=`whoami`
cp ddplot /home/$name/bin
rm ddplot
